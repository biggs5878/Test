class Main {
  public static void main(String[] args) {
    System.out.println("Knowledge is Power!"); //prints Knowledge is Power!
    System.out.println("=============");
    System.out.printf("| Knowledge | %n| is        |%n| Power!    |");//prints Knowledge is Power! in 3 lines
    System.out.println("");// just to allow the one below it to show
    System.out.println("=============");//to make the box for the 5 line
  }
}