class Aboutme {
  public static void main(String[] args){
    var firstname = "Gerald "; //first name
    var lastname =  "Hooper"; //last name
    var age =  "Age: 21"; //age current
    var graduate =  "Gerald graduated from HighSchool in 2018"; // graduation year from highschool
    var quote =  "Favorite Quote: If you do what you love, you'll never work a day in your life.";
    // quote that i hear often that's very true
    //prints the variable above for each one
   System.out.println("Full Name: " + firstname + lastname);
   System.out.println(age);
   System.out.println(graduate);
   System.out.println(quote);
  }
}