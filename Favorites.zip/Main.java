class Main {
  public static void main(String[] args) {
    System.out.println("Name: Gerald");
    System.out.println("Favorite Holiday: Easter");
    System.out.println("Favorite Movie: Sonic the Movie");
    System.out.println("Favorite Musician: Snail House");
  }
}